import "./home.css";

function Home() {
  return (
    <div className="home-container">
      <h1>HOME</h1>
      <div className="second-container">
        <div className="profile"></div>
        <div>
          name: Kannapich Baosri
          <br />
          age: 19
        </div>
      </div>
    </div>
  );
}

export default Home;
